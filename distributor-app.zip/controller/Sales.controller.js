sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("distributor.controller.Sales",{})});
//# sourceMappingURL=Sales.controller.js.map