sap.ui.define(["sap/ui/core/mvc/Controller"],function(r){"use strict";return r.extend("distributor.controller.Stp",{})});
//# sourceMappingURL=STP.controller.js.map