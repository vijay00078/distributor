QUnit.config.autostart=false;sap.ui.require(["distributor/test/integration/AllJourneys"],function(){QUnit.start()});
//# sourceMappingURL=opaTests.qunit.js.map