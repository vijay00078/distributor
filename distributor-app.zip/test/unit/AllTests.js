sap.ui.define(["distributor/test/unit/controller/View1.controller"],function(){"use strict"});
//# sourceMappingURL=AllTests.js.map